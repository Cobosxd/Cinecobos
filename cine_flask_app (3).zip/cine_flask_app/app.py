import os
import logging
from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_mail import Mail, Message
import pyodbc
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime
import imaplib
import email

from forms import MovieForm

# Definir las credenciales del correo
EMAIL_USER = 'fazeji38@gmail.com'
EMAIL_PASS = 'bbdc clgc uooo ujig'  # Tu contraseña de aplicación

# Obtén la ruta absoluta al directorio que contiene app.py
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# Construye la ruta absoluta a la carpeta templates
TEMPLATE_DIR = os.path.join(BASE_DIR, 'app', 'templates')

print(f"BASE_DIR: {BASE_DIR}")
print(f"TEMPLATE_DIR: {TEMPLATE_DIR}")

app = Flask(__name__, template_folder=TEMPLATE_DIR)
app.secret_key = 'tu_clave_secreta'  # ¡Cambia esto por una clave segura!

# Configuración de la carpeta de subida de imágenes
app.config['UPLOAD_FOLDER'] = os.path.join(app.root_path, 'static/uploads')

# Configuración de logging (opcional, pero recomendable)
logging.basicConfig(level=logging.INFO, filename='errores.log')
app.logger.setLevel(logging.ERROR)

# Configuración de Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Configuración para envío de correos
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = os.getenv('MAIL_USERNAME', EMAIL_USER)
app.config['MAIL_PASSWORD'] = os.getenv('MAIL_PASSWORD', EMAIL_PASS)  # Usa la contraseña de aplicación
mail = Mail(app)

# Configuración IMAP para recibir correos
IMAP_SERVER = 'imap.gmail.com'
IMAP_USERNAME = EMAIL_USER
IMAP_PASSWORD = EMAIL_PASS

# Configuración del servidor FTP
FTP_HOST = 'site20844.siteasp.net'
FTP_USER = 'site20844'
FTP_PASS = 'Hp7-6@yXiD_3'
FTP_PORT = 21
FTP_UPLOAD_DIR = '/uploads'
FTP_BASE_URL = 'http://peliculas.runasp.net/'

# Configuración para la subida de archivos
UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


# Configuración de la base de datos SQL Server
SERVER = r'IVµN\MSSQLSERVER02'
DATABASE = 'cine_db'
DRIVER = '{ODBC Driver 17 for SQL Server}'

try:
    conn = pyodbc.connect(
        f'DRIVER={DRIVER};SERVER={SERVER};DATABASE={DATABASE};Trusted_Connection=yes')
    print("Conexión exitosa")
except Exception as e:
    print(f"Error de conexión: {e}")
    app.logger.error(f"Error de conexión: {e}", exc_info=True)
    logging.error(f"Error de conexión: {e}", exc_info=True)
    raise


ADMIN_EMAIL = '23300031@uttt.edu.mx'


def send_error_email(error_details):
    """Envía un correo electrónico al administrador con detalles del error."""
    try:
        msg = Message(
            subject="Error en la Aplicación Cartelera",
            sender=app.config['MAIL_USERNAME'],
            recipients=[ADMIN_EMAIL]
        )
        body = f"""
Ha ocurrido un error en la aplicación:

{error_details}
        """
        msg.body = body.encode('utf-8').decode('utf-8')
        mail.send(msg)
        app.logger.info("Correo de error enviado al administrador.")
    except Exception as mail_error:
        app.logger.error(f"Error al enviar el correo de notificación: {mail_error}", exc_info=True)
        logging.error(f"Error al enviar el correo de notificación: {mail_error}", exc_info=True)

def get_db_connection():
    try:
        conn = pyodbc.connect(
            f'DRIVER={DRIVER};SERVER={SERVER};DATABASE={DATABASE};Trusted_Connection=yes')
        return conn
    except Exception as e:
        logging.error(f"Error al conectar a la base de datos: {e}", exc_info=True)
        app.logger.error(f"Error al conectar a la base de datos: {e}", exc_info=True)
        send_error_email(f"Error al conectar a la base de datos: {e}")
        return None


# Configuración de logs
logging.basicConfig(filename='errores.log', level=logging.ERROR)

# Configuración de Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'


class User(UserMixin):
    def __init__(self, id, username, password, role):
        self.id = id
        self.username = username
        self.password = password
        self.role = role


@login_manager.user_loader
def load_user(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM Usuarios WHERE id = ?', (user_id,))
    user = cursor.fetchone()
    conn.close()
    if user:
        return User(id=user[0], username=user[1], password=user[2], role=user[3])
    return None

# Función de filtro para formatear fechas


def format_datetime(value, format='%Y'):
    if value is None:
        return ''
    return value.strftime(format)


app.jinja_env.filters['strftime'] = format_datetime

# Función para recibir y procesar correos de error desde IMAP
def recibir_correos_error():
    IMAP_SERVER = 'imap.gmail.com'
    IMAP_USERNAME = EMAIL_USER
    IMAP_PASSWORD = EMAIL_PASS
    try:
        mail_imap = imaplib.IMAP4_SSL(IMAP_SERVER)
        mail_imap.login(IMAP_USERNAME, IMAP_PASSWORD)
        mail_imap.select('inbox')

        _, data = mail_imap.search(None, 'ALL')
        mail_ids = data[0]
        id_list = mail_ids.split()

        for num in id_list:
            _, data = mail_imap.fetch(num, '(RFC822)')
            for response_part in data:
                if isinstance(response_part, tuple):
                    msg = email.message_from_bytes(response_part[1])
                    email_subject = msg['subject']
                    email_from = msg['from']

                    if 'Error' in email_subject:
                        for part in msg.walk():
                            if part.get_content_type() == 'text/plain':
                                body = part.get_payload(decode=True).decode()
                                print(f'Correo de error de {email_from}: {body}')
                                # Aquí puedes procesar el error, guardarlo en una base de datos, etc.

        mail_imap.close()
        mail_imap.logout()

    except Exception as e:
        print(f'Error al recibir correos: {e}')

# Rutas de la aplicación
@app.route('/')
def index():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        fecha = request.args.get('fecha')
        busqueda = request.args.get('busqueda')
        genero_busqueda = request.args.get('genero')
        if fecha:
            cursor.execute(
                'SELECT id, titulo, genero, sinopsis, imagen, estado, fecha, trailer_url FROM Pelicula WHERE fecha = ?', (fecha,))
        elif busqueda:
            cursor.execute(
                "SELECT id, titulo, genero, sinopsis, imagen, estado, fecha, trailer_url FROM Pelicula WHERE titulo LIKE ?", ('%' + busqueda + '%',))
        elif genero_busqueda:
            cursor.execute("SELECT id, titulo, genero, sinopsis, imagen, estado, fecha, trailer_url FROM Pelicula WHERE genero LIKE ?",
                           ('%' + genero_busqueda + '%',))
        else:
            cursor.execute(
                'SELECT id, titulo, genero, sinopsis, imagen, estado, fecha, trailer_url FROM Pelicula')
        peliculas = cursor.fetchall()
        conn.close()
        print(f"Contenido de 'peliculas': {peliculas}")
        return render_template('index.html', peliculas=peliculas, now=datetime.now)
    except Exception as e:
        logging.error(f"Error en index: {e}", exc_info=True)
        app.logger.error(f"Error en index: {e}", exc_info=True)
        send_error_email(f"Error en index: {e}")
        return "Error interno del servidor", 500

@app.route('/registro', methods=['GET', 'POST'], endpoint='registro')
def registro():
    try:
        if request.method == 'POST':
            username = request.form['nombre']
            password = request.form['contraseña']
            email = request.form['email']
            role = 'user'
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute('INSERT INTO Usuarios (username, password, email, role) VALUES (?, ?, ?, ?)',
                           (username, password, email, role))
            conn.commit()
            conn.close()
            flash('Registro exitoso. Por favor, inicia sesión.')
            return redirect(url_for('login'))
        return render_template('registro.html', now=datetime.now)
    except Exception as e:
        logging.error(f"Error en registro: {e}", exc_info=True)
        app.logger.error(f"Error en registro: {e}", exc_info=True)
        send_error_email(f"Error en registro: {e}")
        return "Error interno del servidor", 500

@app.route('/login', methods=['GET', 'POST'], endpoint='login')
def login():
    try:
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute(
                'SELECT * FROM Usuarios WHERE username = ? AND password = ?', (username, password))
            user = cursor.fetchone()
            conn.close()
            if user:
                user_obj = User(id=user[0], username=user[1],
                                password=user[2], role=user[3])
                login_user(user_obj)
                return redirect(url_for('admin' if user[3] == 'admin' else 'index'))
            flash('Usuario o contraseña incorrectos')
        return render_template('login.html', now=datetime.now)
    except Exception as e:
        logging.error(f"Error en login: {e}", exc_info=True)
        app.logger.error(f"Error en login: {e}", exc_info=True)
        send_error_email(f"Error en login: {e}")
        return "Error interno del servidor", 500

@app.route('/logout', endpoint='logout')
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/admin', endpoint='admin')
@login_required
def admin():
    if current_user.role != 'admin':
        flash('No tienes permisos para acceder a esta página.', 'danger')
        return redirect(url_for('index'))
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM Pelicula')
        peliculas = cursor.fetchall()
        conn.close()
        return render_template('admin.html', peliculas=peliculas, now=datetime.now)
    except Exception as e:
        logging.error(f"Error en admin: {e}", exc_info=True)
        app.logger.error(f"Error en admin: {e}", exc_info=True)
        send_error_email(f"Error en admin: {e}")
        return "Error interno del servidor", 500

@app.route('/admin/add_movie', methods=['GET', 'POST'], endpoint='add_movie')
@login_required
def add_movie():
    if current_user.role != 'admin':
        return redirect(url_for('index'))
    form = MovieForm()
    try:
        if form.validate_on_submit():
            titulo = form.titulo.data
            genero = form.genero.data
            sinopsis = form.sinopsis.data
            imagen_file = form.imagen.data
            estado = form.estado.data
            fecha = form.fecha.data
            trailer_url = form.trailer_url.data

            if imagen_file and allowed_file(imagen_file.filename):
                filename = secure_filename(imagen_file.filename)
                local_filepath = os.path.join(
                    app.config['UPLOAD_FOLDER'], filename)
                try:
                    imagen_file.save(local_filepath)
                    imagen_ruta_db = os.path.join('/uploads', filename).replace('\\', '/')
                    try:
                        conn = get_db_connection()
                        cursor = conn.cursor()
                        cursor.execute('INSERT INTO Pelicula (titulo, genero, sinopsis, imagen, estado, fecha, trailer_url) VALUES (?, ?, ?, ?, ?, ?, ?)',
                                       (titulo, genero, sinopsis, imagen_ruta_db, estado, fecha, trailer_url))
                        conn.commit()
                        conn.close()
                        flash('Película añadida con éxito.', 'success')
                        return redirect(url_for('admin'))
                    except Exception as db_err:
                        logging.error(f"Error de base de datos: {db_err}", exc_info=True)
                        app.logger.error(f"Error de base de datos: {db_err}", exc_info=True)
                        flash('Error al añadir película (base de datos).', 'danger')
                        return redirect(url_for('add_movie'))
                except Exception as local_file_err:
                    logging.error(f"Error al guardar archivo local: {local_file_err}", exc_info=True)
                    app.logger.error(f"Error al guardar archivo local: {local_file_err}", exc_info=True)
                    flash('Error al guardar archivo local.', 'danger')
                    return redirect(url_for('add_movie'))
            else:
                flash('Por favor, selecciona un archivo de imagen válido.', 'warning')
        return render_template('add_movie.html', form=form, now=datetime.now)
    except Exception as e:
        logging.error(f"Error en add_movie: {e}", exc_info=True)
        app.logger.error(f"Error en add_movie: {e}", exc_info=True)
        send_error_email(f"Error en add_movie: {e}")
        return "Error interno del servidor", 500

@app.route('/admin/edit_movie/<int:id>', methods=['GET', 'POST'], endpoint='edit_movie')
@login_required
def edit_movie(id):
    if current_user.role != 'admin':
        return redirect(url_for('index'))
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM Pelicula WHERE id = ?', (id,))
    pelicula = cursor.fetchone()
    conn.close()
    if pelicula is None:
        flash('Película no encontrada.', 'danger')
        return redirect(url_for('admin'))
    form = MovieForm(obj=pelicula)
    try:
        if form.validate_on_submit():
            titulo = form.titulo.data
            genero = form.genero.data
            sinopsis = form.sinopsis.data
            imagen_file = form.imagen.data
            estado = form.estado.data
            fecha = form.fecha.data
            trailer_url = form.trailer_url.data
            imagen_ruta_db = pelicula[4]

            if imagen_file and allowed_file(imagen_file.filename):
                filename = secure_filename(imagen_file.filename)
                local_filepath = os.path.join(
                    app.config['UPLOAD_FOLDER'], filename)
                try:
                    imagen_file.save(local_filepath)
                    imagen_ruta_db = os.path.join('/uploads', filename).replace('\\', '/')
                except Exception as local_file_err:
                    logging.error(f"Error al guardar archivo local: {local_file_err}", exc_info=True)
                    app.logger.error(f"Error al guardar archivo local: {local_file_err}", exc_info=True)
                    flash('Error al guardar archivo local.', 'danger')
                    return redirect(url_for('edit_movie', id=id))

            try:
                conn = get_db_connection()
                cursor = conn.cursor()
                cursor.execute('UPDATE Pelicula SET titulo=?, genero=?, sinopsis=?, imagen=?, estado=?, fecha=?, trailer_url=? WHERE id=?',
                               (titulo, genero, sinopsis, imagen_ruta_db, estado, fecha, trailer_url, id))
                conn.commit()
                conn.close()
                flash('Película actualizada con éxito.', 'success')
                return redirect(url_for('admin'))
            except Exception as e:
                logging.error(f"Error al actualizar película: {e}", exc_info=True)
                app.logger.error(f"Error al actualizar película: {e}", exc_info=True)
                flash('Error al actualizar película. Por favor, intenta de nuevo.', 'danger')
                return redirect(url_for('edit_movie', id=id))
        return render_template('edit_movie.html', form=form, pelicula_id=id, pelicula=pelicula, now=datetime.now)
    except Exception as e:
        logging.error(f"Error en edit_movie: {e}", exc_info=True)
        app.logger.error(f"Error en edit_movie: {e}", exc_info=True)
        send_error_email(f"Error en edit_movie: {e}")
        return "Error interno del servidor", 500

@app.route('/admin/delete_movie/<int:id>', endpoint='delete_movie')
@login_required
def delete_movie(id):
    if current_user.role != 'admin':
        return redirect(url_for('index'))
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM Pelicula WHERE id = ?', (id,))
        conn.commit()
        conn.close()
        flash('Película eliminada con éxito.', 'success')
    except Exception as e:
        logging.error(f"Error al eliminar película: {e}", exc_info=True)
        app.logger.error(f"Error al eliminar película: {e}", exc_info=True)
        send_error_email(f"Error al eliminar película: {e}")
        flash('Error al eliminar película. Por favor, intenta de nuevo.', 'danger')
    return redirect(url_for('admin'))

@app.route('/cartelera', endpoint='cartelera')
def cartelera():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            'SELECT id, titulo, genero, sinopsis, imagen, estado, fecha, trailer_url FROM Pelicula')
        peliculas = cursor.fetchall()
        conn.close()
        return render_template('cartelera.html', peliculas=peliculas, now=datetime.now)
    except Exception as e:
        logging.error(f"Error en cartelera: {e}", exc_info=True)
        app.logger.error(f"Error en cartelera: {e}", exc_info=True)
        send_error_email(f"Error en cartelera: {e}")
        return "Error interno del servidor", 500

@app.route('/pelicula/<int:id>', endpoint='pelicula_detalles')
def pelicula_detalles(id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM Pelicula WHERE id = ?', (id,))
        pelicula = cursor.fetchone()
        conn.close()
        if pelicula:
            print(f"Estructura de pelicula: {pelicula}")
            return render_template('pelicula_detalles.html', pelicula=pelicula, now=datetime.now)
        else:
            return "Película no encontrada", 404
    except Exception as e:
        logging.error(f"Error en pelicula_detalles: {e}", exc_info=True)
        app.logger.error(f"Error en pelicula_detalles: {e}", exc_info=True)
        send_error_email(f"Error en pelicula_detalles: {e}")
        return "Error interno del servidor", 500

@app.route('/compra_boletos', endpoint='compra_boletos')
def compra_boletos():
    return "Página de Compra de Boletos"

@app.route('/contacto', endpoint='contacto')
@login_required
def contacto():
    return render_template('contacto.html', now=datetime.now)

@app.route('/procesar_errores', endpoint='procesar_errores')
def procesar_errores():
    recibir_correos_error()
    return 'Errores procesados'

# Ruta de prueba para el envío de correos
@app.route('/test_email')
def test_email():
    try:
        msg = Message(
            subject="Correo de prueba",
            sender=app.config['MAIL_USERNAME'],
            recipients=[ADMIN_EMAIL]
        )
        msg.body = "Este es un correo electrónico de prueba."
        mail.send(msg)
        return "Correo de prueba enviado"
    except Exception as e:
        return f"Error al enviar correo de prueba: {e}"

# Ejecutar la aplicación
if __name__ == '__main__':
    print("Iniciando aplicación Flask...")
    app.run(debug=True, use_reloader=False)