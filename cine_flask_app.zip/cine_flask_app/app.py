from flask import Flask, render_template, request, redirect, url_for, flash, session
import pyodbc
import logging
import smtplib
from email.mime.text import MIMEText
import os
from ftplib import FTP
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.utils import secure_filename
from forms import MovieForm
from flask_bootstrap import Bootstrap

# Inicialización de la aplicación Flask
app = Flask(__name__, template_folder='C:/Users/Ivan_/cine_flask_app/app/templates')
app.config['SECRET_KEY'] = 'supersecretkey'  # Clave secreta para manejar sesiones
bootstrap = Bootstrap(app)  # Inicializa Flask-Bootstrap

# Configuración del servidor FTP
FTP_HOST = 'site20844.siteasp.net'  # Servidor FTP
FTP_USER = 'site20844'  # Usuario FTP
FTP_PASS = 'Hp7-6@yXiD_3'  # Contraseña FTP
FTP_PORT = 21  # Puerto FTP
FTP_UPLOAD_DIR = '/uploads'  # Ruta en el servidor FTP donde se subirán los archivos
FTP_BASE_URL = 'http://peliculas.runasp.net/'

# Configuración para la subida de archivos
UPLOAD_FOLDER = 'static/uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Configuración de la base de datos SQL Server
SERVER = r'IVµN\MSSQLSERVER02'  # Verifica que esté bien escrito
DATABASE = 'cine_db'
DRIVER = '{ODBC Driver 17 for SQL Server}'

try:
    conn = pyodbc.connect(f'DRIVER={DRIVER};SERVER={SERVER};DATABASE={DATABASE};Trusted_Connection=yes')
    print("Conexión exitosa")
except Exception as e:
    print(f"Error de conexión: {e}")

def get_db_connection():
    return pyodbc.connect(f'DRIVER={DRIVER};SERVER={SERVER};DATABASE={DATABASE};Trusted_Connection=yes')

# Configuración de logs
logging.basicConfig(filename='errores.log', level=logging.ERROR)

# Configuración de Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'  # Ruta a la que se redirige si el usuario no está autenticado

class User(UserMixin):
    def __init__(self, id, username, password, role):
        self.id = id
        self.username = username
        self.password = password
        self.role = role

@login_manager.user_loader
def load_user(user_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM Usuarios WHERE id = ?', (user_id,))
    user = cursor.fetchone()
    conn.close()
    if user:
        return User(id=user[0], username=user[1], password=user[2], role=user[3])
    return None

# Rutas de la aplicación
@app.route('/')
def index():
    conn = get_db_connection()
    cursor = conn.cursor()
    fecha = request.args.get('fecha')
    busqueda = request.args.get('busqueda')
    if fecha:
        cursor.execute('SELECT id, titulo, genero, sinopsis, imagen, estado, fecha, trailer_url FROM Pelicula WHERE fecha = ?', (fecha,))
    elif busqueda:
        cursor.execute("SELECT id, titulo, genero, sinopsis, imagen, estado, fecha, trailer_url FROM Pelicula WHERE titulo LIKE ?", ('%' + busqueda + '%',))
    else:
        cursor.execute('SELECT id, titulo, genero, sinopsis, imagen, estado, fecha, trailer_url FROM Pelicula')
    peliculas = cursor.fetchall()
    conn.close()
    print(f"Contenido de 'peliculas': {peliculas}")  # Agrega esta línea para depurar
    return render_template('index.html', peliculas=peliculas)

@app.route('/registro', methods=['GET', 'POST'], endpoint='registro')
def registro():
    if request.method == 'POST':
        username = request.form['nombre']
        password = request.form['contraseña']
        email = request.form['email']
        role = 'user'
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO Usuarios (username, password, email, role) VALUES (?, ?, ?, ?)',
                       (username, password, email, role))
        conn.commit()
        conn.close()
        flash('Registro exitoso. Por favor, inicia sesión.')
        return redirect(url_for('login'))
    return render_template('registro.html')

@app.route('/login', methods=['GET', 'POST'], endpoint='login')
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM Usuarios WHERE username = ? AND password = ?', (username, password))
        user = cursor.fetchone()
        conn.close()
        if user:
            user_obj = User(id=user[0], username=user[1], password=user[2], role=user[3])
            login_user(user_obj)
            return redirect(url_for('admin' if user[3] == 'admin' else 'index'))
        flash('Usuario o contraseña incorrectos')
    return render_template('login.html')

@app.route('/logout', endpoint='logout')
def logout():
    logout_user()
    return redirect(url_for('index'))


@app.route('/admin/add_movie', methods=['GET', 'POST'], endpoint='add_movie')
@login_required
def add_movie():
    if current_user.role != 'admin':
        return redirect(url_for('index'))
    form = MovieForm()
    if form.validate_on_submit():
        logging.info("Formulario enviado y validado con éxito.")
        titulo = form.titulo.data
        genero = form.genero.data
        sinopsis = form.sinopsis.data
        imagen_file = form.imagen.data
        estado = form.estado.data
        fecha = form.fecha.data
        trailer_url = form.trailer_url.data
        logging.info(f"Título: {titulo}, Género: {genero}, Sinopsis: {sinopsis}, Estado: {estado}, Fecha: {fecha}, Trailer URL: {trailer_url}, Imagen: {imagen_file.filename if imagen_file else None}")
        if imagen_file and allowed_file(imagen_file.filename):
            filename = secure_filename(imagen_file.filename)
            local_filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            remote_filepath = os.path.join(FTP_UPLOAD_DIR, filename)
            try:
                imagen_file.save(local_filepath)
                logging.info(f"Archivo guardado localmente en: {local_filepath}")
                try:
                    ftp = FTP()
                    logging.info(f"Intentando conexión FTP a {FTP_HOST}:{FTP_PORT} con usuario {FTP_USER}")
                    ftp.connect(FTP_HOST, FTP_PORT)
                    logging.info(f"Respuesta FTP: {ftp.getwelcome()}")
                    ftp.login(FTP_USER, FTP_PASS)
                    logging.info("Login FTP exitoso.")
                    ftp.cwd(FTP_UPLOAD_DIR)
                    logging.info(f"Directorio FTP actual: {ftp.pwd()}")
                    with open(local_filepath, 'rb') as file:
                        ftp_filename = os.path.basename(remote_filepath)
                        logging.info(f"Subiendo {filename} por FTP como {ftp_filename}...")
                        ftp.storbinary(f'STOR {ftp_filename}', file)
                        logging.info(f"Archivo {filename} subido por FTP exitosamente como {ftp_filename}.")
                    ftp.quit()
                    imagen_ruta_db = os.path.join(FTP_UPLOAD_DIR, ftp_filename)
                    logging.info(f"Ruta de la imagen guardada en la base de datos: {imagen_ruta_db}")
                    try:
                        conn = get_db_connection()
                        cursor = conn.cursor()
                        cursor.execute('INSERT INTO Pelicula (titulo, genero, sinopsis, imagen, estado, fecha, trailer_url) VALUES (?, ?, ?, ?, ?, ?, ?)',
                                       (titulo, genero, sinopsis, imagen_ruta_db, estado, fecha, trailer_url))
                        conn.commit()
                        conn.close()
                        logging.info("Película insertada en la base de datos.")
                        flash('Película añadida con éxito.')
                        return redirect(url_for('admin'))
                    except pyodbc.Error as db_err:
                        logging.error(f"Error de base de datos al insertar película: {db_err}")
                        flash('Error al añadir película (base de datos). Por favor, revisa los logs.', 'danger')
                        return redirect(url_for('add_movie'))
                except Exception as ftp_err:
                    logging.error(f"Error al subir imagen por FTP: {ftp_err}")
                    flash('Error al subir imagen por FTP. Por favor, intenta de nuevo.', 'danger')
                    return redirect(url_for('add_movie'))
            except Exception as local_file_err:
                logging.error(f"Error al guardar el archivo localmente: {local_file_err}")
                flash('Error al guardar el archivo local. Por favor, intenta de nuevo.', 'danger')
                return redirect(url_for('add_movie'))
        else:
            logging.warning(f"Archivo de imagen no válido o no seleccionado: {imagen_file.filename if imagen_file else 'Ninguno'}")
            flash('Por favor, selecciona un archivo de imagen válido.', 'warning')
    else:
        logging.info(f"El formulario no es válido. Errores: {form.errors}")
        flash('Por favor, corrige los errores en el formulario.', 'danger')
    return render_template('add_movie.html', form=form)

@app.route('/admin/edit_movie/<int:id>', methods=['GET', 'POST'], endpoint='edit_movie')
@login_required
def edit_movie(id):
    if current_user.role != 'admin':
        return redirect(url_for('index'))
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM Pelicula WHERE id = ?', (id,))
    pelicula = cursor.fetchone()
    conn.close()
    if pelicula is None:
        flash('Película no encontrada.', 'danger')
        return redirect(url_for('admin'))
    form = MovieForm(obj=pelicula)
    if form.validate_on_submit():
        titulo = form.titulo.data
        genero = form.genero.data
        sinopsis = form.sinopsis.data
        imagen_file = form.imagen.data
        estado = form.estado.data
        fecha = form.fecha.data
        trailer_url = form.trailer_url.data
        imagen_ruta_db = pelicula[4]
        if imagen_file and allowed_file(imagen_file.filename):
            filename = secure_filename(imagen_file.filename)
            local_filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            remote_filepath = os.path.join(FTP_UPLOAD_DIR, filename)
            try:
                imagen_file.save(local_filepath)
                try:
                    ftp = FTP()
                    ftp.connect(FTP_HOST, FTP_PORT)
                    ftp.login(FTP_USER, FTP_PASS)
                    ftp.cwd('/')
                    with open(local_filepath, 'rb') as file:
                        ftp.storbinary(f'STOR {remote_filepath}', file)
                    ftp.quit()
                    os.remove(local_filepath)
                    imagen_ruta_db = remote_filepath
                except Exception as ftp_err:
                    logging.error(f"Error al subir nueva imagen por FTP: {ftp_err}")
                    flash('Error al subir la nueva imagen. Por favor, intenta de nuevo.', 'danger')
                    return redirect(url_for('edit_movie', id=id))
                except Exception as local_err:
                    logging.error(f"Error al guardar archivo local temporal: {local_err}")
                    flash('Error al guardar archivo temporal. Por favor, intenta de nuevo.', 'danger')
                    return redirect(url_for('edit_movie', id=id))
                except Exception as save_err:
                    logging.error(f"Error al guardar archivo local: {save_err}")
                    flash('Error al guardar el archivo de imagen. Por favor, intenta de nuevo.', 'danger')
                    return redirect(url_for('edit_movie', id=id))
                except Exception as save_local_err:
                    logging.error(f"Error al guardar el archivo local: {save_local_err}")
                    flash('Error al guardar el archivo de imagen local. Por favor, intenta de nuevo.', 'danger')
                    return redirect(url_for('edit_movie', id=id))
            except Exception as e_save_outer:  # Manejo de la excepción del primer save
                logging.error(f"Error al guardar el archivo local inicialmente: {e_save_outer}")
                flash('Error al guardar el archivo de imagen local. Por favor, intenta de nuevo.', 'danger')
                return redirect(url_for('edit_movie', id=id))

        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute('UPDATE Pelicula SET titulo=?, genero=?, sinopsis=?, imagen=?, estado=?, fecha=?, trailer_url=? WHERE id=?',
                           (titulo, genero, sinopsis, imagen_ruta_db, estado, fecha, trailer_url, id))
            conn.commit()
            conn.close()
            flash('Película actualizada con éxito.', 'success')
            return redirect(url_for('admin'))
        except Exception as e:
            logging.error(f"Error al actualizar película: {e}")
            flash('Error al actualizar película. Por favor, intenta de nuevo.', 'danger')
            return redirect(url_for('edit_movie', id=id))
    return render_template('edit_movie.html', form=form, pelicula_id=id, pelicula=pelicula)

@app.route('/admin/delete_movie/<int:id>', endpoint='delete_movie')
@login_required
def delete_movie(id):
    if current_user.role != 'admin':
        return redirect(url_for('index'))
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM Pelicula WHERE id = ?', (id,))
        conn.commit()
        conn.close()
        flash('Película eliminada con éxito.', 'success')
    except Exception as e:
        logging.error(f"Error al eliminar película: {e}")
        flash('Error al eliminar película. Por favor, intenta de nuevo.', 'danger')
    return redirect(url_for('admin'))

@app.route('/cartelera', endpoint='cartelera')
def cartelera():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT id, titulo, genero, sinopsis, imagen, estado, fecha, trailer_url FROM Pelicula')
    peliculas = cursor.fetchall()
    conn.close()
    return render_template('cartelera.html', peliculas=peliculas)


@app.route('/pelicula/<int:id>', endpoint='pelicula_detalles')
def pelicula_detalles(id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM Pelicula WHERE id = ?', (id,))
        pelicula = cursor.fetchone()
        conn.close()
        if pelicula:
            return render_template('pelicula_detalles.html', pelicula=pelicula)
        else:
            return "Película no encontrada", 404
    except Exception as e:
        logging.error(f"Error en pelicula_detalles: {e}")
        return "Error interno del servidor", 500

@app.route('/compra_boletos', endpoint='compra_boletos')
def compra_boletos():
    return "Página de Compra de Boletos"

@app.route('/contacto', endpoint='contacto')
@login_required
def contacto():
    return render_template('contacto.html')

# Ejecutar la aplicación
if __name__ == '__main__':
    print("Iniciando aplicación Flask...")
    app.run(debug=True, use_reloader=False)