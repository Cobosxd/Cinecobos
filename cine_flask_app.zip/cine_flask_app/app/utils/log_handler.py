import logging
import smtplib
from email.mime.text import MIMEText

def log_error(error):
    logging.error(str(error))
    send_error_email(str(error))

def send_error_email(error_message):
    msg = MIMEText(error_message)
    msg['Subject'] = 'Error en la aplicación de cine'
    msg['From'] = 'error@cineapp.com'
    msg['To'] = 'admin@cineapp.com'

    with smtplib.SMTP('smtp.cineapp.com') as server:
        server.send_message(msg)